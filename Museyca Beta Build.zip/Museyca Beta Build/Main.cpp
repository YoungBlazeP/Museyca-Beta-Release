#include "Engine.h"
int main(int argc, char* args[]) // Main MUST have these parameters for SDL.
{
	//Engine e; // Milestone 4s of 1007 assignment did NOT use a Singleton yet.
	//return e.Run();
	return Engine::Instance().Run();
}